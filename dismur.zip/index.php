<?php header('Location: public/');
