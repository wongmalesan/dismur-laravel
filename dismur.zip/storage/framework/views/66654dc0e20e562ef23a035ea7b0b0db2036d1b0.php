<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Daftar Merchant'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

<div class="container">
    <div class="card mt-5">
        <div class="card-body">
            <a href="/admin/merchant/tambahMerchant" class="btn btn-primary">Input Merchant Baru</a>
            <br />
            <br />
            <table class="table table-bordered table-hover table-striped">
                <thead>
                    <tr>
                        <th>ID Merchant</th>
                        <th>Nama Merchant</th>
                        <th>Alamat Merchant</th>
                        <th>Map Location</th>
                        <th>Logo</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $m; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Mdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($Mdata->id_merchant); ?></td>
                        <td><?php echo e($Mdata->nama_merchant); ?></td>
                        <td><?php echo e($Mdata->alamat_merchant); ?></td>
                        <td><?php echo e($Mdata->map_location); ?></td>
                        <td>
                            <img width="150px" src="<?php echo e(url('/main-asset-dismur/img/merchant/'.$Mdata->logo)); ?>">
                        </td>
                        <td>
                            <a href="/admin/merchant/editMerchant/<?php echo e($Mdata->id_merchant); ?>" class="btn btn-warning" title="Edit"><i class="fas fa-edit"></i></a>
                            <a href="/admin/merchant/hapusMerchant/<?php echo e($Mdata->id_merchant); ?>" class="btn btn-danger" title="Delete"><i class="fas fa-times"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ============================================= -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/admin-page/Amerchant.blade.php ENDPATH**/ ?>