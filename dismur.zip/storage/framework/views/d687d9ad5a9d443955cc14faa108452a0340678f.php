<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Dashboard Admin Merchant'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>
<div class="container">
    <div class="card">
        <div class="card-body">
        <img width="150px" src="<?php echo e(url('/image/default-avatar.png')); ?>" class="mb-5">
            <dl class="row">
                <dt class="col-sm-3">Id Merchant</dt>
                <dd class="col-sm-7"><?php echo e($merchant->id_merchant); ?></dd>

                <dt class="col-sm-3">Nama Merchant</dt>
                <dd class="col-sm-7"><?php echo e($merchant->nama_merchant); ?></dd>

                <dt class="col-sm-3">Alamat Merchant</dt>
                <dd class="col-sm-7"><?php echo e($merchant->alamat_merchant); ?></dd>

                <dt class="col-sm-3 text-truncate">Map Location</dt>
                <dd class="col-sm-7"><?php echo e($merchant->map_location); ?></dd>

                <dt class="col-sm-3">Logo Merchant</dt>
                <dd class="col-sm-7"><?php echo e($merchant->logo); ?></dd>
            </dl>
            <a href="/merchant/profile/edit/<?php echo e($merchant->id_merchant); ?>" class="btn btn-warning" style="float:right;" title="Edit"><i class="fas fa-edit"></i></a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('merchant-page.master_merchant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/merchant-page/merchant_profile.blade.php ENDPATH**/ ?>