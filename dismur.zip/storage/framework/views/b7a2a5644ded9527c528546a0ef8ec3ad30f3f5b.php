<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Tambah Merchant'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

<div class="container">
    <div class="card mt-5">
        <div class="card-body">
            <form method="post" action="/admin/merchant/tambahMerchant/simpan">

                <?php echo e(csrf_field()); ?>


                <!-- <div class="form-group">
                    <label>id_kategori</label>
                    <input type="text" name="id_kategori" class="form-control" placeholder="id Kategori ..">

                    <?php if($errors->has('id_kategori')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('id_kategori')); ?>

                    </div>
                    <?php endif; ?>

                </div> -->

                <div class="form-group">
                    <label>Nama Merchant</label>
                    <input type="text" name="nama_merchant" class="form-control" placeholder="Nama Merchant ..">

                    <?php if($errors->has('nama_merchant')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('nama_kategori')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Alamat Merchant</label>
                    <textarea name="alamat_merchant" class="form-control" placeholder="Alamat Merchant .."></textarea>

                    <?php if($errors->has('alamat_merchant')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('alamat_kategori')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Map Location</label>
                    <input type="text" name="map_location" class="form-control" placeholder="URL Map Location ..">

                    <?php if($errors->has('map_location')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('map_location')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Logo</label>
                    <input type="text" name="logo_merchant" class="form-control" placeholder="Choose Image ..">

                    <?php if($errors->has('logo_merchant')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('logo_merchant')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <input type="submit" class="btn btn-success" value="Simpan">
                </div>

            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/Amerchant_add.blade.php ENDPATH**/ ?>