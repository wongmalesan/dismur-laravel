<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Data Member'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

<div class="container">
    <div class="card">
        <div class="card-body">
            <a href="/admin/member/tambah" class="btn btn-primary">Tambah Member</a>
            <br />
            <br />
            <table class="table table-bordered table-hover table-striped">
                <thead>
                    <tr>
                        <th>ID Member</th>
                        <th>Nama Member</th>
                        <th>Email Member</th>
                        <th>Tanggal Daftar</th>
                        <th>Foto</th>
                        <th>ID Referal Member</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $senddata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->id_member); ?></td>
                        <td><?php echo e($data->nama_member); ?></td>
                        <td><?php echo e($data->email_member); ?></td>
                        <td><?php echo e($data->tanggal_daftar); ?></td>
                        <td>
                            <img width="150px" src="<?php echo e(url('/main-asset-dismur/img/member/'.$data->foto_member)); ?>">
                        </td>
                        <td><?php echo e($data->id_referal); ?></td>
                        <td>
                            <a href="/admin/member/edit/<?php echo e($data->id_member); ?>" class="btn btn-warning" title="Edit"><i class="fas fa-edit"></i></a>
                            <a href="/admin/member/hapus/<?php echo e($data->id_member); ?>" class="btn btn-danger" title="Delete"><i class="fas fa-times"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/admin-page/Amember.blade.php ENDPATH**/ ?>