<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Dashboard Admin Merchant'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

<div class="profile-user-info">
    <div class="profile-info-row">
        <div class="profile-info-name"> Id Merchant </div>

        <div class="profile-info-value">
            <span><?php echo e($merchant->id_merchant); ?></span>
        </div>
    </div>

    <div class="profile-info-row">
        <div class="profile-info-name"> Nama Merchant </div>

        <div class="profile-info-value">
            <span><?php echo e($merchant->nama_merchant); ?></span>
        </div>
    </div>

    <div class="profile-info-row">
        <div class="profile-info-name"> Alamat Merchant </div>

        <div class="profile-info-value">
            <span><?php echo e($merchant->alamat_merchant); ?></span>
        </div>
    </div>

    <div class="profile-info-row">
        <div class="profile-info-name"> Map Location </div>

        <div class="profile-info-value">
            <span><?php echo e($merchant->map_location); ?></span>
        </div>
    </div>

    <div class="profile-info-row">
        <div class="profile-info-name"> Logo Merchant </div>

        <div class="profile-info-value">
            <span><?php echo e($merchant->logo_merchant); ?></span>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/dashboard-merchant.blade.php ENDPATH**/ ?>