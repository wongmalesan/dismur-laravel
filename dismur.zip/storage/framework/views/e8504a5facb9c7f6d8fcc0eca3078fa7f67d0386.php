<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Edit Admin'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

<div class="container">
    <div class="card mt-5">
        <div class="card-body">
            <form method="post" action="/admin/dataAdmin/edit/update/<?php echo e($ad->id_admin); ?>">

                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                <div class="form-group">
                    <label>Nama Admin</label>
                    <input type="text" name="nama_admin" class="form-control" value="<?php echo e($ad->nama_admin); ?>">

                    <?php if($errors->has('nama_admin')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('nama_admin')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Email Admin</label>
                    <input class="form-control" name="email_admin" type="email" value="<?php echo e($ad->email_admin); ?>">

                    <?php if($errors->has('email_admin')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('email_admin')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Alamat Admin</label>
                    <textarea class="form-control" name="alamat_admin" value="<?php echo e($ad->alamat_admin); ?>"></textarea>

                    <?php if($errors->has('alamat_admin')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('alamat_admin')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Telepon</label>
                    <input type="text" name="telepon_admin" class="form-control" value="<?php echo e($ad->telepon_admin); ?>">

                    <?php if($errors->has('telepon_admin')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('telepon_admin')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <input type="submit" class="btn btn-success" value="Simpan">
                </div>

            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/admin-page/Adata_admin_edit.blade.php ENDPATH**/ ?>