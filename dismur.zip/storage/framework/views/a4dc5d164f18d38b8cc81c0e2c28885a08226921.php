<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Form Tambah Member'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

<div class="container">
    <div class="card mt-5">
        <div class="card-body">
            <form method="post" enctype="multipart/form-data" action="/admin/member/tambah/simpan">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <label>Nama Member</label>
                    <input type="text" name="nama_member" class="form-control" placeholder="Nama Admin ..">

                    <?php if($errors->has('nama_member')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('nama_member')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Email Member</label>
                    <input class="form-control" name="email_member" type="email" placeholder="Email Admin">

                    <?php if($errors->has('email_member')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('email_member')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Upload Foto</label>
                    <br>
                    <input type="file" name="foto_member" class="mb-2">

                    <?php if($errors->has('foto_member')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('foto_member')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <input type="submit" class="btn btn-success" value="Simpan">
                </div>

            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/admin-page/Amember_add.blade.php ENDPATH**/ ?>