<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Dashboard Admin Merchant'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>
<div class="container">
    <div class="card">
        <div class="card-body">
        <img width="150px" src="<?php echo e(url('/image/default-avatar.png')); ?>" class="mb-5">
            <dl class="row">
                <dt class="col-sm-3">Id Member</dt>
                <dd class="col-sm-7"><?php echo e($member->id_member); ?></dd>

                <dt class="col-sm-3">Nama Member</dt>
                <dd class="col-sm-7"><?php echo e($member->nama_member); ?></dd>

                <dt class="col-sm-3">Email Member</dt>
                <dd class="col-sm-7"><?php echo e($member->email_member); ?></dd>

                <dt class="col-sm-3">Foto Member</dt>
                <dd class="col-sm-7"><?php echo e($member->foto_member); ?></dd>

                <dt class="col-sm-3">id_referal</dt>
                <dd class="col-sm-7"><?php echo e($member->id_referal); ?></dd>
            </dl>
            <a href="/member/profile/edit/<?php echo e($member->id_member); ?>" class="btn btn-warning" style="float:right;" title="Edit"><i class="fas fa-edit"></i></a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('member-page.master_member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/member-page/member_profile.blade.php ENDPATH**/ ?>