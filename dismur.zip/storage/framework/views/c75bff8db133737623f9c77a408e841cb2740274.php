<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Edit Merchant'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

<div class="container">
    <div class="card mt-5">
        <div class="card-body">
            <form method="post" enctype="multipart/form-data" action="/admin/merchant/editMerchant/update/<?php echo e($m->id_merchant); ?>">

                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <label>Nama Merchant</label>
                    <input type="text" name="nama_merchant" class="form-control" value="<?php echo e($m->nama_merchant); ?>">

                    <?php if($errors->has('nama_merchant')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('nama_kategori')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Alamat Merchant</label>
                    <textarea name="alamat_merchant" class="form-control">
                    <?php echo e($m->alamat_merchant); ?>

                    </textarea>

                    <?php if($errors->has('alamat_merchant')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('alamat_kategori')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Map Location</label>
                    <input type="text" name="map_location" class="form-control" value="<?php echo e($m->map_location); ?>">

                    <?php if($errors->has('map_location')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('map_location')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Logo</label>
                    <br>
                    <input type="file" name="logo_merchant" class="mb-2">
                    <br>
                    <label>Logo Saat ini</label><br>
                    <img width="150px" src="<?php echo e(url('/main-asset-dismur/img/merchant/'.$m->logo)); ?>">

                    <?php if($errors->has('logo')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('logo')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <input type="submit" class="btn btn-success" value="Simpan">
                </div>

            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/admin-page/Amerchant_edit.blade.php ENDPATH**/ ?>