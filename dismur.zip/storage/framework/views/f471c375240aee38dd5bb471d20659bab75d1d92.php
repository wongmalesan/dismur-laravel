<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Dashboard Admin'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

<div class="container">
    <div class="card mt-5">
        <div class="card-body">
            <table class="table table-bordered table-hover table-striped">
                <thead>
                    <tr>
                        <th>ID Merchant</th>
                        <th>Nama Merchant</th>
                        <th>Alamat Merchant</th>
                        <th>Map Location</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $m; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Mdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($Mdata->id_merchant); ?></td>
                        <td><?php echo e($Mdata->nama_merchant); ?></td>
                        <td><?php echo e($Mdata->alamat_merchant); ?></td>
                        <td><?php echo e($Mdata->map_location); ?></td>
                        <td>
                            <a href="/merchant/edit/<?php echo e($Mdata->id_merchant); ?>" class="btn btn-warning">Edit</a>
                            <a href="/merchant/hapus/<?php echo e($Mdata->id_merchant); ?>" class="btn btn-danger">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ============================================= -->

    <div class="card mt-5">
        <div class="card-body">
            <table class="table table-bordered table-hover table-striped">
                <thead>
                    <tr>
                        <th>ID Kategori</th>
                        <th>Nama Kategori Produk</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $KPdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($KPdata->id_kategori); ?></td>
                        <td><?php echo e($KPdata->nama_kategori); ?></td>
                        <td>
                            <a href="/kategori/edit/<?php echo e($KPdata->id_kategori); ?>" class="btn btn-warning">Edit</a>
                            <a href="/kategori/hapus/<?php echo e($KPdata->id_kategori); ?>" class="btn btn-danger">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/merchant.blade.php ENDPATH**/ ?>