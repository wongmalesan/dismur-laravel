<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Dashboard Admin'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

<div class="container">
    <div class="card mt-5">
        <div class="card-body">
            <a href="/kategori" class="btn btn-primary">Kembali</a>
            <br />
            <br />

            <form method="post" action="/kategori/simpan">

                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <label>id_kategori</label>
                    <input type="text" name="id_kategori" class="form-control" value="<?php echo e($id); ?>" readonly>

                    <?php if($errors->has('id_kategori')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('id_kategori')); ?>

                    </div>
                    <?php endif; ?>

                </div>

                <div class="form-group">
                    <label>Nama Kategori</label>
                    <input name="nama_kategori" class="form-control" placeholder="Nama Kategori ..">

                    <?php if($errors->has('nama_kategori')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('nama_kategori')); ?>

                    </div>
                    <?php endif; ?>

                </div>

                <div class="form-group">
                    <input type="submit" class="btn btn-success" value="Simpan">
                </div>

            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/kategoriTambah.blade.php ENDPATH**/ ?>