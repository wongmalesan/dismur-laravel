<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Dashboard Data Admin'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

<div class="container">
    <div class="card">
        <div class="card-body">
            <a href="/admin/dataAdmin/tambah" class="btn btn-primary">Tambah Admin</a>
            <br />
            <br />
            <table class="table table-bordered table-hover table-striped">
                <thead>
                    <tr>
                        <th>ID Admin</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Alamat</th>
                        <th>Nomor Telepon</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->id_admin); ?></td>
                        <td><?php echo e($data->nama_admin); ?></td>
                        <td><?php echo e($data->email_admin); ?></td>
                        <td><?php echo e($data->alamat_admin); ?></td>
                        <td><?php echo e($data->telepon_admin); ?></td>
                        <td>
                            <!-- <a href="/admin/dataAdmin/tambah/<?php echo e($data->id_admin); ?>" class="btn btn-success" title="Hooray!"><i class="fas fa-plus"></i></a> -->
                            <a href="/admin/dataAdmin/edit/<?php echo e($data->id_admin); ?>" class="btn btn-warning" title="Edit"><i class="fas fa-edit"></i></a>
                            <a href="/admin/dataAdmin/hapus/<?php echo e($data->id_admin); ?>" class="btn btn-danger" title="Delete"><i class="fas fa-times"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/admin-page/Adata_admin.blade.php ENDPATH**/ ?>