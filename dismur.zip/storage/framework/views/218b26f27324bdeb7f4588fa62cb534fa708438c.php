<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Dashboard Admin'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

<div class="container">
    <div class="card mt-5">
        <div class="card-body">
            <form method="post" action="/admin/produk/editProduk/update/<?php echo e($p->id_produk); ?>">

                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                <div class="form-group">
                    <label>Nama Produk</label>
                    <input type="text" name="nama_produk" class="form-control" value="<?php echo e($p->nama_produk); ?>">

                    <?php if($errors->has('nama_produk')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('nama_produk')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Event Begin</label>
                    <!-- <input class="form-control" name="event_begin" type="datetime-local"> -->
                    <input class="form-control" name="event_begin" type="text" value="<?php echo e($p->event_begin); ?>">

                    <?php if($errors->has('event_begin')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('event_begin')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Event End</label>
                    <!-- <input class="form-control" name="event_end" type="datetime-local"> -->
                    <input class="form-control" name="event_end" type="text" value="<?php echo e($p->event_end); ?>">

                    <?php if($errors->has('event_end')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('event_end')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Diskon</label>
                    <input type="text" name="diskon" class="form-control" value="<?php echo e($p->diskon); ?>">

                    <?php if($errors->has('diskon')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('diskon')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Kategori Produk</label>
                    <select class="form-control" name="kategori_produk">
                        <?php $__currentLoopData = $kAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $krow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($krow->id_kategori == $k->id_kategori): ?>
                                <option id="<?php echo e($krow->id_kategori); ?>" value="<?php echo e($krow->id_kategori); ?>" selected ><?php echo e($krow->nama_kategori); ?></option>
                            <?php else: ?>
                                <option id="<?php echo e($krow->id_kategori); ?>" value="<?php echo e($krow->id_kategori); ?>"><?php echo e($krow->nama_kategori); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <?php if($errors->has('kategori_produk')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('kategori_produk')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Gambar Produk</label>
                    <input type="text" name="foto_produk" class="form-control" value="<?php echo e($p->foto_produk); ?>">

                    <?php if($errors->has('foto_produk')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('foto_produk')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <input type="submit" class="btn btn-success" value="Simpan">
                </div>

            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/Aproduk_edit.blade.php ENDPATH**/ ?>