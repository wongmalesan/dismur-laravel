<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Dashboard Admin'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

<div class="container">
    <div class="card mt-5">
        <div class="card-body">
            <form method="post" action="/merchant/update/<?php echo e($merchant->id_merchant); ?>">

                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                <div class="form-group">
                    <label>Nama Merchant</label>
                    <input type="text" name="nama_merchant" class="form-control" value="<?php echo e($merchant->nama_merchant); ?>">

                    <?php if($errors->has('nama_merchant')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('nama_merchant')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Alamat Merchant</label>
                    <input type="text" name="alamat_merchant" class="form-control" value="<?php echo e($merchant->alamat_merchant); ?>">

                    <?php if($errors->has('alamat_merchant')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('alamat_merchant')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Map Location</label>
                    <input type="text" name="map_location" class="form-control" value="<?php echo e($merchant->map_location); ?>">

                    <?php if($errors->has('map_location')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('map_location')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <input type="submit" class="btn btn-success" value="Simpan">
                </div>

            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/merchantEdit.blade.php ENDPATH**/ ?>