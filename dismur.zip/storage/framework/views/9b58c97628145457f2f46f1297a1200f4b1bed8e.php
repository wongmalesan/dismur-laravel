<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Registration'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

<div class="container">
    <div class="card mt-5">
        <div class="card-body">
            <form method="post" action="/reg/member/simpan">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <label>Nama Member</label>
                    <input type="text" name="nama_member" class="form-control" placeholder="Nama Admin ..">

                    <?php if($errors->has('nama_member')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('nama_member')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Email Member</label>
                    <input class="form-control" name="email_member" type="email" placeholder="Email Admin">

                    <?php if($errors->has('email_member')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('email_member')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input class="form-control" name="password_confirmation" type="password" placeholder="Enter Password ...">

                    <?php if($errors->has('password_confirmation')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('password_confirmation')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Verifikasi Password</label>
                    <input class="form-control" name="password" type="password" placeholder="Verified Password ...">

                    <?php if($errors->has('password')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('password')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Upload Foto</label>
                    <input class="form-control" name="foto_member">

                    <?php if($errors->has('foto_member')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('foto_member')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <input type="submit" class="btn btn-success" value="Simpan">
                </div>

            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('form-registrasi.master_reg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/form-registrasi/member_reg.blade.php ENDPATH**/ ?>