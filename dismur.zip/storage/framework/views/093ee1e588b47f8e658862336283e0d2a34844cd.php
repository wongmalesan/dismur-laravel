<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Daftar Produk'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <a href="/merchant/produk/tambah" class="btn btn-primary">Input Produk Baru</a>
                <br />
                <br />
                <table class="table table-bordered table-hover table-striped">
                    <thead>
                        <tr>
                            <th>ID Produk</th>
                            <th>Nama Produk</th>
                            <th>Tanggal</th>
                            <th>Event Begin Date</th>
                            <th>Event End Date</th>
                            <th>Harga</th>
                            <th>Diskon(%)</th>
                            <th>Penambah</th>
                            <th>Kategori</th>
                            <th>Gambar Produk</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $senddata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($data->id_produk); ?></td>
                            <td><?php echo e($data->nama_produk); ?></td>
                            <td><?php echo e($data->tanggal_input); ?></td>
                            <td><?php echo e($data->event_begin); ?></td>
                            <td><?php echo e($data->event_end); ?></td>
                            <td><?php echo e($data->harga); ?></td>
                            <td><?php echo e($data->diskon); ?></td>
                            <td><?php echo e($data->id_merchant); ?></td>
                            <td><?php echo e($data->id_kategori); ?></td>
                            <td><?php echo e($data->foto_produk); ?></td>
                            <td>
                                <a href="/merchant/produk/edit/<?php echo e($data->id_produk); ?>" class="btn btn-warning" title="Edit"><i class="fas fa-edit"></i></a>
                                <a href="/merchant/produk/hapus/<?php echo e($data->id_produk); ?>" class="btn btn-danger" title="Delete"><i class="fas fa-times"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('merchant-page.master_merchant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/merchant-page/merchant_produk.blade.php ENDPATH**/ ?>