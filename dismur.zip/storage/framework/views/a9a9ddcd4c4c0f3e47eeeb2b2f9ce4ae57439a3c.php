<!-- Menghubungkan dengan view template master -->


<!-- isi bagian judul halaman -->
<!-- cara penulisan isi section yang pendek -->
<?php $__env->startSection('judul_halaman', 'Edit Merchant'); ?>


<!-- isi bagian konten -->
<!-- cara penulisan isi section yang panjang -->
<?php $__env->startSection('konten'); ?>

<div class="container">
    <div class="card mt-5">
        <div class="card-body">
            <form method="post" action="/member/profile/edit/update/<?php echo e($member->id_member); ?>">

                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>


                <div class="form-group">
                    <label>Nama Member</label>
                    <input type="text" name="nama_member" class="form-control" value="<?php echo e($member->nama_member); ?>">

                    <?php if($errors->has('nama_member')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('nama_member')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Email Member</label>
                    <input name="email_member" class="form-control" type="email" value="<?php echo e($member->email_member); ?>">

                    <?php if($errors->has('email_member')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('email_member')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label>Foto Member</label>
                    <input type="text" name="foto_member" class="form-control" value="<?php echo e($member->foto_member); ?>">

                    <?php if($errors->has('foto_member')): ?>
                    <div class="text-danger">
                        <?php echo e($errors->first('foto_member')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <input type="submit" class="btn btn-success" value="Simpan">
                </div>

            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('member-page.master_member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Programmer\Laravel\dismur\resources\views/member-page/member_profile_edit.blade.php ENDPATH**/ ?>